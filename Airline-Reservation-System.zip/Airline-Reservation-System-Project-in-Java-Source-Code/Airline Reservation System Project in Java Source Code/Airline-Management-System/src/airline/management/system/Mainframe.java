package airline.management.system;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


public class Mainframe extends JFrame{

    public static void main(String[] args) {
        new Mainframe().setVisible(true);
    }

    public Mainframe() {
        super("AIRLINE SYSTEM PROJECT");
        initialize();
    }


    private void initialize() {

        setForeground(Color.CYAN);
        setLayout(null);

        JLabel NewLabel = new JLabel("");
	NewLabel.setIcon(new ImageIcon(ClassLoader.getSystemResource("airline/management/system/icon/AIR.jpg")));
	NewLabel.setBounds(0, 0, 1920, 990);
	add(NewLabel);

        JLabel AirlineManagementSystem = new JLabel("Welcome To AAD Airline, ENJOY  THE CLOUDS");
	AirlineManagementSystem.setForeground(Color.BLUE);
        AirlineManagementSystem.setFont(new Font("Tahoma", Font.PLAIN, 36));
	AirlineManagementSystem.setBounds(550, 60, 1000, 75);
	NewLabel.add(AirlineManagementSystem);


        JMenuBar menuBar = new JMenuBar();
	setJMenuBar(menuBar);

        JMenu FlightDetail = new JMenu("FLIGHT_INFO");
        FlightDetail.setForeground(Color.BLUE);
        menuBar.add(FlightDetail);

    JMenuItem FlightDetails = new JMenuItem("FLIGHT_INFO");
        FlightDetail.add(FlightDetails);


        JMenu Reservation = new JMenu("RESERVATION");
        Reservation.setForeground(Color.BLUE);
        menuBar.add(Reservation);

        JMenuItem Reservations = new JMenuItem("RESERVATION");
        Reservation.add(Reservations);


        JMenu ReservationDetail = new JMenu("ADD_CUSTOMER");
        ReservationDetail.setForeground(Color.BLUE);
        menuBar.add(ReservationDetail);

	JMenuItem ReservationDetails = new JMenuItem("ADD_CUSTOMER_DETAILS");
        ReservationDetail.add(ReservationDetails);

        JMenu PassengerDetail = new JMenu("JOURNEY_DETAILS");
        PassengerDetail.setForeground(Color.BLUE);
        menuBar.add(PassengerDetail);


	JMenuItem PassengerDetails = new JMenuItem("JOURNEY_DETAILS");
        PassengerDetail.add(PassengerDetails);


        JMenu PaymentDetails = new JMenu("PAYMENT_DETAILS");
        PaymentDetails.setForeground(Color.BLUE);
        menuBar.add(PaymentDetails);

        JMenuItem SectorDetails_1 = new JMenuItem("PAYMENT_DETAILS");
        PaymentDetails.add(SectorDetails_1);


        JMenu Cancellations = new JMenu("CANCELLATION");
        Cancellations.setForeground(Color.BLUE);
        menuBar.add(Cancellations);

	JMenuItem Cancellation = new JMenuItem("CANCELLATION");
        Cancellations.add(Cancellation);

      	
	FlightDetails.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                new Flight_Info();
            }
	});

        Reservations.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                new Reservation();
            }
        });

        ReservationDetails.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                try {
                    new Add_Customer();
		} catch (Exception e) {
                    e.printStackTrace();
		}
            }
	});

      PassengerDetails.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                try {
                    new Journey_Details();
                } catch (Exception e) {
                    e.printStackTrace();
		}
            }
	});

        SectorDetails_1.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                try {
                    new Payment_Details();
		} catch (Exception e) {
                    e.printStackTrace();
		}
            }
	});

        Cancellation.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                new Cancel();
            }
	});
        JButton Next = new JButton("NOTIFICATION");
        Next.setBounds(1750, 20, 150, 30);
        Next.setBackground(Color.blue);
        Next.setForeground(Color.WHITE);
        add(Next);

        String[] messages = {"You have a new notification!", "Check your inbox!", "Don't forget to reply!"};
        final int[] messageIndex = {0}; // Declare messageIndex as a final array

        Next.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Show the notification with the count of unread notifications
                int notificationCount = 1; // replace with your actual notification count
                String notificationMessage = "You have " + notificationCount + " new notifications.";

                JOptionPane.showMessageDialog(null, notificationMessage, "Notification", JOptionPane.INFORMATION_MESSAGE);

                // Open a new window or dialog box to show the data
                JFrame frame = new JFrame("notification");
                frame.setSize(400, 300);

                JLabel label = new JLabel("flights between China and India have been affected. I would recommend checking with your airline or airport for the latest information on any changes or cancellations to your flight.");
                label.setBounds(100, 100, 200, 30);
                frame.add(label);

                frame.setVisible(true);
            }
        });

        setSize(1950,1090);
	setVisible(true);
    }
}
